/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 *
 * @author User
 */
public class SiteSearch
{
    private TestWebsite driver;
    public SiteSearch(TestWebsite driver)
    {
        this.driver = driver;
    }

    void search(String selector, String str)
    {
        WebElement element = GetDriverWebElement.get(driver, selector);
        element.sendKeys(str);
        element.submit();
    }
    
}
