/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import org.openqa.selenium.By;

/**
 *
 * @author User
 */
public class ChangeOfSort
{
    private TestWebsite driver;
    public static final int RELEVANCE = 1;
    public static final int ALPH_FROM_SMALLEST = 2;
    public static final int ALPH_FROM_LARGEST = 3;
    public static final int PRICE_FROM_SMALLEST = 4;
    public static final int PRICE_FROM_LARGEST = 5;
    
    private By byComboboxSort = By.cssSelector("div[class$='dropdown']>a[class='select-title']");

    public ChangeOfSort(TestWebsite driver)
    {
        this.driver = driver;
    }
    public void changeSort(int id)
    {

        GetDriverWebElement.get(driver.getDriver(), byComboboxSort).click();
        try
        {
            GetDriverWebElement.get(driver.getDriver(), "div[class$='dropdown open']>div[class='dropdown-menu']>a:nth-child("+id+")", 1).click();
        }
        catch(Exception e)
        {
            GetDriverWebElement.get(driver.getDriver(), byComboboxSort).click();
            GetDriverWebElement.get(driver, "div[class$='dropdown open']>div[class='dropdown-menu']>a:nth-child("+id+")").click();
        }
       
       
        driver.waitDriverJS();
    }
}
