/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;


import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.events.WebDriverEventListener;

/**
 *
 * @author User
 */
public class EventHandler implements WebDriverEventListener
{ 
//    private OutputStreamWriter writer;
//    private BufferedWriter writer;
    private String pathname = "log.txt";
    private File file;
    public EventHandler()
    {
        this.file = new File(pathname);
        try
        {
            PrintWriter pw = new PrintWriter(this.file);
            pw.close();
        } catch (IOException ex)
        {
            Logger.getLogger(EventHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void writeFile(String str)
    {
 
       str+="\n";
       try (BufferedWriter writer = Files.newBufferedWriter(file.toPath(), StandardOpenOption.APPEND)) 
       {
           writer.write(str);
       } catch (IOException ioe) 
       {
           System.err.format("IOException: %s%n", ioe);
       }

    }
    @Override
    public void beforeAlertAccept(WebDriver wd)
    {

    }
    @Override
    public void afterAlertAccept(WebDriver wd)
    {

    }
    @Override
    public void afterAlertDismiss(WebDriver wd)
    {

    }
    @Override
    public void beforeAlertDismiss(WebDriver wd)
    {

    }
    @Override
    public void beforeNavigateTo(String string, WebDriver wd)
    {

    }

    @Override
    public void afterNavigateTo(String string, WebDriver wd)
    {

    }
    @Override
    public void beforeNavigateBack(WebDriver wd)
    {

    }

    @Override
    public void afterNavigateBack(WebDriver wd)
    {

    }
    @Override
    public void beforeNavigateForward(WebDriver wd)
    {
        
    }
    @Override
    public void afterNavigateForward(WebDriver wd)
    {
       
    }
    @Override
    public void beforeNavigateRefresh(WebDriver wd)
    {
 
    }
    @Override
    public void afterNavigateRefresh(WebDriver wd)
    {
 
    }
    @Override
    public void beforeFindBy(By by, WebElement we, WebDriver wd)
    {
        this.writeFile("--\nSearch "+by);
    }
    @Override
    public void afterFindBy(By by, WebElement we, WebDriver wd)
    {
        this.writeFile("Found "+by);
    }
    @Override
    public void beforeClickOn(WebElement we, WebDriver wd)
    {
        this.writeFile("--\nShould click " + we.toString());
    }

    @Override
    public void afterClickOn(WebElement we, WebDriver wd)
    {
        this.writeFile("Clicked successfull " + we.toString());
    }

    @Override
    public void beforeChangeValueOf(WebElement we, WebDriver wd, CharSequence[] css)
    {

    }

    @Override
    public void afterChangeValueOf(WebElement we, WebDriver wd, CharSequence[] css)
    {
        this.writeFile("After change "+we+"\n"+arrToString(css, "\n"));
    }

    @Override
    public void beforeScript(String string, WebDriver wd)
    {

    }

    @Override
    public void afterScript(String string, WebDriver wd)
    {
 
    }

    @Override
    public void onException(Throwable thrwbl, WebDriver wd)
    {
        this.writeFile("---\n"+"Exception " + thrwbl.getMessage()+"\n---");
    }
    private String arrToString(CharSequence[] arr, String separator)
    {
        StringBuilder builder = new StringBuilder();
        for(CharSequence val:arr)
        {
            builder.append(val.toString());
            builder.append(separator);
        }
        return builder.toString();
    }
}
