/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

/**
 *
 * @author User
 */
public class TestWebsite
{
    private WebDriver driver;
    private String url;
    private EventFiringWebDriver eventFiringWebDriver;
    public TestWebsite(String url)
    {
        this.url = url;
    }
    @BeforeMethod()
    public void Create()
    {
        System.setProperty("webdriver.gecko.driver", "C:\\BrowserDrivers\\geckodriver.exe");

        this.driver = new FirefoxDriver();
        this.driver.manage().deleteAllCookies();
        this.driver.get(this.url);
        
        
        this.eventFiringWebDriver =  new EventFiringWebDriver(driver).register(new EventHandler());
      
//        this.driver.navigate().to(this.url);
//        this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
    
    public WebDriver getDriver()
    {
//        return this.driver;
        return this.eventFiringWebDriver;
    }
    public TestWebsite getWDriver()
    {
        return this;
    }
    @AfterMethod()
    public void closeDriver()
    {
//        try
//        {
//            FileWriter writer = new FileWriter("log.txt", false);
//            
//            for(LogEntry  str:logEntries)
//            {
//                writer.write(str.toString()+"\n");
//            }
//            writer.flush();
//            writer.close();
//        } catch (IOException ex)
//        {
//            Logger.getLogger(EventHandler.class.getName()).log(Level.SEVERE, null, ex);
//        }
        this.driver.close();
    }
    public void waitDriverJS()
    {
        (new WebDriverWait(driver, 2000)).until((ExpectedCondition<Boolean>) (WebDriver driver1) -> 
        {
            JavascriptExecutor js = (JavascriptExecutor) driver1;
            return (Boolean) js.executeScript("return jQuery.active == 0");
        });
    }
}
