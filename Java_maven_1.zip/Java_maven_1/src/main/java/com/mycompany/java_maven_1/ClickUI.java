/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import org.openqa.selenium.WebDriver;

/**
 *
 * @author User
 */
public class ClickUI
{
    private ClickUI(){}
    public static void сlickWaitJS(TestWebsite driver,String selector)
    {
        GetDriverWebElement.get(driver, selector).click();
        driver.waitDriverJS();
    }
}
