/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

/**
 *
 * @author User
 */
public class ExistsElement
{
    private ExistsElement(){}
    public static boolean existsElement(TestWebsite driver, String selector) 
    {
        try 
        {

//            (new WebDriverWait(driver.getDriver(), 1)).until
//            (
//                ExpectedConditions.presenceOfElementLocated(By.cssSelector(selector))
//            );
           
            driver.getDriver().findElement(By.cssSelector(selector));
        } catch (NoSuchElementException e) 
        {
            return false;
        }
        return true;
    }
    public static boolean existsElement(WebElement element, String selector) 
    {
        try 
        {
            element.findElement(By.cssSelector(selector));
        } catch (NoSuchElementException e) 
        {
            return false;
        }
        return true;
    }
}
