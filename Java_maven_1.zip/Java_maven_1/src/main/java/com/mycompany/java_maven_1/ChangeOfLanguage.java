/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import org.openqa.selenium.WebDriver;

/**
 *
 * @author User
 */
public class ChangeOfLanguage
{
    private TestWebsite driver;
    public static final int ID_RU = 1;
    public static final int ID_UA = 2;
    
    public ChangeOfLanguage(TestWebsite driver)
    {
        this.driver = driver;
    }

    public void changeLanguage(int language)
    {
        GetDriverWebElement.get(driver, "div[class='language-selector dropdown js-dropdown']>span").click();
        GetDriverWebElement.get(driver, "div[class$='open']>ul[class$='hidden-sm-down']>li:nth-child("+language+")>a").click();
    }
    
}
