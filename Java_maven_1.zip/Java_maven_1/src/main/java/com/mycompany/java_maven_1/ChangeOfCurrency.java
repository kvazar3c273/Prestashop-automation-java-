/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import org.junit.Test;

/**
 *
 * @author User
 */
public class ChangeOfCurrency
{
    private TestWebsite driver;
    private int[] cur = new int[]{1,2,3};
    public static final int ID_EUR = 0;
    public static final int ID_UAN = 1;
    public static final int ID_USD = 2;
    
    public ChangeOfCurrency(TestWebsite driver)
    {
        this.driver = driver;
    }
    @Test
    public void changeCurrency(int currency)
    {

        GetDriverWebElement.get(driver, "div[id='_desktop_currency_selector']>div>span[class$='hidden-sm-down']").click();
        GetDriverWebElement.get(driver, "div[class$='open']>ul[class$='hidden-sm-down']>li:nth-child("+cur[currency]+")>a").click();
        driver.waitDriverJS();
    }
    public int[] getCurIndex()
    {
        return this.cur;
    }
    
}
