/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author User
 */
public class GetDriverWebElement
{
    private GetDriverWebElement(){}
    
    public static WebElement get(TestWebsite driver, String selector)
    {
        WebElement element = (new WebDriverWait(driver.getDriver(), 10)).until
            (
                ExpectedConditions.presenceOfElementLocated(By.cssSelector(selector))
            );

        return element;
    }
    public static WebElement get(WebDriver driver, String selector, int s)
    {
        return (new WebDriverWait(driver, s)).until
            (
                ExpectedConditions.presenceOfElementLocated(By.cssSelector(selector))
            );
    }
    public static WebElement get(WebDriver driver, By by)
    {
        return (new WebDriverWait(driver, 10)).until
            (
                ExpectedConditions.presenceOfElementLocated(by)
            );
    }
    
    public static List<WebElement> getList(TestWebsite driver, String selector)
    {
       WebDriverWait wait = new WebDriverWait(driver.getDriver(), 10);
       
       
       return wait.until(new ExpectedCondition<List<WebElement>>() 
        {
            @Override
            public List<WebElement> apply(WebDriver driver)
            {
                return  driver.findElements(By.cssSelector(selector));
            }
        });         
    }
    public static List<WebElement> getList(TestWebsite driver, WebElement element, String selector)
    {

       WebDriverWait wait = new WebDriverWait(driver.getDriver(), 10);
       return wait.until(new ExpectedCondition<List<WebElement>>() 
        {
            @Override
            public List<WebElement> apply(WebDriver driver)
            {
                return  element.findElements(By.cssSelector(selector));
            }
        });         
    }
    public static WebElement get(WebDriver driver,WebElement element, String selector)
    {
       WebDriverWait wait = new WebDriverWait(driver, 10);
       return wait.until(new ExpectedCondition<WebElement>() 
        {
            @Override
            public WebElement apply(WebDriver driver)
            {
                return  element.findElement(By.cssSelector(selector));
            }
        });   
    }
    
}
