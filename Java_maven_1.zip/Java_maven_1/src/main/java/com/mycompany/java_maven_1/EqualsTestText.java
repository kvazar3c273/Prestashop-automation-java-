/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import org.openqa.selenium.By;

/**
 *
 * @author User
 */
public class EqualsTestText
{
    private TestWebsite driver;
    public EqualsTestText(TestWebsite driver)
    {
        this.driver = driver;
    }
    public boolean checkEqualsText(String selector1, String selector2)
    {
//        By value1 = By.cssSelector(selector1);
//        By value2 = By.cssSelector(selector2);
//        String str1 = driver.getDriver().findElement(value1).getText();
//        String str2 = driver.getDriver().findElement(value2).getText();

        String str1 = GetDriverWebElement.get(driver, selector1).getText();
        String str2 = GetDriverWebElement.get(driver, selector2).getText();
        
        return str1.equals(str2);
    }
    public String getText(String selector)
    {
        return GetDriverWebElement.get(driver, selector).getText().trim();
    }
   
}
