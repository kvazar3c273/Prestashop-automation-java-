/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.WebElement;

/**
 *
 * @author User
 */
public class Main
{
    public static void main(String[] args)
    {
        TestWebsite testWebsite = new TestWebsite("http://prestashop-automation.qatestlab.com.ua/ru/");
        testWebsite.Create();

        EqualsTestText equalsTestToText = new EqualsTestText(testWebsite);
        InfoContainer infoContainer = new InfoContainer(testWebsite);
        ChangeOfCurrency changeOfCurrency = new ChangeOfCurrency(testWebsite);
        SiteSearch sr = new SiteSearch(testWebsite);
        ChangeOfSort changeOfSort = new ChangeOfSort(testWebsite);
       
        System.out.println("\n==========================");
        if(!equalsTestToText.getText("div[class='language-selector dropdown js-dropdown']>span").toLowerCase().equals("русский"))
        {
            ChangeOfLanguage language = new ChangeOfLanguage(testWebsite);
            language.changeLanguage(ChangeOfLanguage.ID_RU);
        }
        String nameSection = equalsTestToText.getText("h1[class='h1 products-section-title text-uppercase ']");
        if(nameSection.toLowerCase().equals("популярные товары"))
        {
            for(int i=0; i<changeOfCurrency.getCurIndex().length; i++)
            {
                changeOfCurrency.changeCurrency(changeOfCurrency.getCurIndex()[i]-1);
                String str2 = equalsTestToText.getText("span~span[class='expand-more _gray-darker hidden-sm-down']");
                boolean chCurInfo = true;
                List<WebElement> webElements = infoContainer.getElementsContainer("div[class='products']>article[class$='js-product-miniature'] div[class='product-price-and-shipping']>span[class='price']");
                for(WebElement element:webElements)
                {
                    boolean chCur = checkCurrency(element.getText(),str2);
                    if(!chCur)
                    {
                        System.err.println("ERR: несовпадение валюты, установлено: "+str2+", на товаре: "+element.getText());
                        chCurInfo = false;
                    }
                }
                if(chCurInfo)
                    System.out.println("Валюта "+str2+" в шапке совпадает с валютой установленной на товарах");
            }
            System.out.println("");
        }
        else
            System.err.println("ERR: секция называется \""+nameSection+"\", вместо: \"ПОПУЛЯРНЫЕ ТОВАРЫ\"");
        
       
        changeOfCurrency.changeCurrency(ChangeOfCurrency.ID_USD);
        
        
        sr.search("#search_widget input[class='ui-autocomplete-input']", "dress");
        
        int searchTotalProducts = infoContainer.getNumberRes(".total-products>p");
        System.out.println("Результат поиска: "+searchTotalProducts);
        
        ArrayList<Integer> quantityGoods = infoContainer.getNumbersRes("nav[class='pagination']>div:first-child");
        if(quantityGoods != null)
        {
                
            int numberPages =  infoContainer.numberOfItemsInContainer("ul[class='page-list clearfix text-xs-center']>li")-2;
            System.out.println("NP = "+numberPages);

            int paginationCurNumder = quantityGoods.get(1);                
            int paginationTotalNumber = quantityGoods.get(2);
            int numOfPages = infoContainer.numberOfItemsInContainer("div[class='products row']>article");

            System.out.println("Products found per page: "+searchTotalProducts+",\npagination Current number: "+paginationCurNumder+
                    ",\npagination total number: "+paginationTotalNumber+",\nnumber of pages: "+numOfPages+",\nN pages: "+numberPages);

            int quantityOfGoods = 0;
               
            for(int i=0; i<numberPages; i++)
            {
                if(numberPages>1)
                    ClickUI.сlickWaitJS(testWebsite, "a[class^='next']");
       
                int n = infoContainer.numberOfItemsInContainer("div[class^='products']>article");
                quantityOfGoods +=n;
        
                /**
                 * Проверка, что цена всех показанных результатов отображается в долларах
                 */
       
                List<WebElement> webElements = infoContainer.getElementsContainer("div[class^='products']>article[class$='js-product-miniature'] div[class='product-price-and-shipping']>span[class='price']");
                System.out.println(webElements.size());
                webElements.forEach((element) ->
                {
                    System.out.println("Валюта товара: $ = "+checkCurrency(element.getText(),"$"));
                });
            }
            
            if(quantityOfGoods != searchTotalProducts)
                System.err.println("ERR: Количество найденных ("+quantityOfGoods+") товаров НЕ совпадает с результатом ("+searchTotalProducts+") на странице");
            else
                System.out.println("Количество найденных ("+quantityOfGoods+") товаров совпадает с результатом ("+searchTotalProducts+") на странице");

            for(int i = 0; i<numberPages; i++)
                ClickUI.сlickWaitJS(testWebsite, "a[class^='previous']");
        }
        
        changeOfSort.changeSort(ChangeOfSort.PRICE_FROM_LARGEST);
        /**
         * проверка сортировки
         */
        testSort(testWebsite, infoContainer);
        

        System.out.println("=========================================");
        testWebsite.closeDriver();
    }
    private static boolean checkCurrency(String str1, String str2)
    {
        if(str1.length() == 0 || str2.length() == 0)
            return false;
        
        char ch1 = str1.charAt(str1.length()-1);
        char ch2 = str2.charAt(str2.length()-1);
      
        return ch1==ch2;
    }
    private static void testSort(TestWebsite testWebsite, InfoContainer infoContainer)
    {
        
        System.out.println("----------------------------------");
        List<WebElement> sortElement = infoContainer.getElementsContainer("div[class^='products']>article[class$='js-product-miniature']");
        System.out.println(sortElement.size());

        int numberPages =  infoContainer.numberOfItemsInContainer("ul[class='page-list clearfix text-xs-center']>li")-2;

        for(int i=0; i<numberPages; i++)
        {
            if(numberPages>1)
                ClickUI.сlickWaitJS(testWebsite, "a[class^='next']");

            List<WebElement> webElements = infoContainer.getElementsContainer("div[class^='products']>article[class$='js-product-miniature'] div[class='product-price-and-shipping']");

            if(webElements.size() == 0)
                continue;

            double prPrice = checkPrice(webElements.get(0), infoContainer);
            double price = 0;
            
            System.out.println("price = "+prPrice);
            for(int j = 1; j<webElements.size(); j++)
            {
                price =  checkPrice(webElements.get(j), infoContainer);
                if(prPrice<price)
                    System.err.println("ERR: ошибка в сортировке");
                System.out.println("price = "+price);
                
                prPrice = price;
            }
        }
        for(int i = 0; i<numberPages; i++)
             ClickUI.сlickWaitJS(testWebsite, "a[class^='previous");
  
   }   
   private static double checkPrice(WebElement element, InfoContainer infoContainer)
   {
       double price = 0;
       if(infoContainer.numberOfItemsInContainer(element, "span") > 1)
        {
            price = infoContainer.getDecimalStr(infoContainer.getElementElemContainer(element, "div[class='product-price-and-shipping']>span[class='regular-price']").getText());
            double discount = 0;
            double discountPrice = 0;
            
            if((ExistsElement.existsElement(element, "div[class='product-price-and-shipping']>span[class='discount-percentage']")))
                discount = infoContainer.getDecimalStr(infoContainer.getElementElemContainer(element,"div[class='product-price-and-shipping']>span[class='discount-percentage']").getText());
            else
                System.out.println("Не указан процент скидки");
            if((ExistsElement.existsElement(element, "div[class='product-price-and-shipping']>span[class='discount-percentage']")))
                discountPrice = infoContainer.getDecimalStr(infoContainer.getElementElemContainer(element,"div[class='product-price-and-shipping']>span[class='price']").getText());
            else
                System.out.println("Не указана цена со скидкой");
            
            double calcDiscount = Math.round((discountPrice*100/price)-100);
            System.out.println("--"+discount+"%, priceDis: "+discountPrice+", price: "+price);
            if(calcDiscount != discount)
                System.err.println("ERR: указанная скидка: "+discount+", а реальная: "+calcDiscount);
            else
                System.out.println("Скидка ("+ discount+") указана верно");
        }
        else
            price = infoContainer.getDecimalStr(infoContainer.getElementElemContainer(element, "span[class='price']").getText());
        
       return price;
   }
}
