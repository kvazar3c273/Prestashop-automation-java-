/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.java_maven_1;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 *
 * @author User
 */
public class InfoContainer
{
    private TestWebsite driver;
    public InfoContainer(TestWebsite driver)
    {
        this.driver = driver;
    }
    public int getNumberRes(String selector)
    {
        By value = By.cssSelector(selector);
        int N = -1;
        try
        {
//            N = Integer.parseInt((new WebDriverWait(driver, 10)).until
//            (
//                    ExpectedConditions.presenceOfElementLocated(value)
//            ).getText().replaceAll("\\D+", ""));
            N = Integer.parseInt(GetDriverWebElement.get(driver.getDriver(), value).getText().replaceAll("\\D+", ""));
        }
        catch(Exception e){}
        return N;
    }
    public ArrayList<Integer> getNumbersRes(String selector)
    {
        String[] strN;
        try
        {  
            strN = GetDriverWebElement.get(driver, selector).getText().split("\\D+");
            if(strN.length>0)
            {
                ArrayList<Integer> N = new ArrayList<>();
                for(int i=0; i<strN.length; i++)
                    if(!strN[i].contains(" ") && strN[i].length()>0)
                        N.add(Integer.parseInt(strN[i]));  
                return N;
            }
        }
        catch(Exception e){System.out.println(e.getMessage());}
                
        return null;
    }
    
    public double getDecimalRes(String selector)
    {
        return getDecimalStr(GetDriverWebElement.get(driver, selector).getText());
    }
    
    public ArrayList<Double> getDecimalsRes(String selector)
    {
        By value = By.cssSelector(selector);
        return  getDecimalsStr(GetDriverWebElement.get(driver.getDriver(),value).getText());
    }
    public double getDecimalStr(String str)
    {
        double N = 0;
        try
        {
            StringBuilder num = new StringBuilder();
            for(int i=0; i<str.length(); i++)
            {
                if(str.charAt(i) >= '0' && str.charAt(i)<='9' || str.charAt(i) == '.' || str.charAt(i) == ','|| str.charAt(i) == '-')
                    num.append(str.charAt(i) == ','?'.':str.charAt(i));
                
            }
            N = Double.parseDouble(num.toString());
        }
        catch(Exception e){}
        return N;
    }
    public ArrayList<Double> getDecimalsStr(String str)
    {
       ArrayList<Double> doubles = new ArrayList<>();
       try
       {
           StringBuilder num = new StringBuilder();
           for(int i=0; i<str.length(); i++)
           {
               if(str.charAt(i) >= '0' && str.charAt(i)<='9' || str.charAt(i) == '.' || str.charAt(i) == ','|| str.charAt(i) == '-')
               {
                   num.append(str.charAt(i) == ','?'.':str.charAt(i));
                   if(str.charAt(i) == ',' || str.charAt(i) == '.')
                       continue;
               }
               if(i==str.length()-1 && num.length()>0 || num.length()>0 && (str.charAt(i) <'0' || str.charAt(i)>'9'))
               {
                   doubles.add(Double.parseDouble(num.toString()));
                   num.setLength(0);
                   num = new StringBuilder();
               }
           }
       }
       catch(Exception e){System.err.println(e.getMessage());}
       return doubles;
    }
    public int numberOfItemsInContainer(String selector)
    {
        return GetDriverWebElement.getList(driver, selector).size();
    }
    public List<WebElement> getElementsContainer(String selector)
    {
        return GetDriverWebElement.getList(driver, selector);
    }
    public WebElement getElementElemContainer(String selector)
    {
        return GetDriverWebElement.get(driver,selector);
    }
    public int numberOfItemsInContainer(WebElement element,String selector)
    {
        return GetDriverWebElement.getList(driver,element,selector).size();
    }
    public List<WebElement> getElementsContainer(WebElement element, String selector)
    {
//        return  element.findElements(By.cssSelector(selector));
        return GetDriverWebElement.getList(driver,element,selector);
    }
    public WebElement getElementElemContainer(WebElement element, String selector)
    {
       // return element.findElement(By.cssSelector(selector));
        return GetDriverWebElement.get(driver.getDriver(),element,selector);
    }
}
